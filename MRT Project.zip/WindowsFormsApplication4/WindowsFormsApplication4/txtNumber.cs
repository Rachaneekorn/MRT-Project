﻿internal class txtNumber
{
}