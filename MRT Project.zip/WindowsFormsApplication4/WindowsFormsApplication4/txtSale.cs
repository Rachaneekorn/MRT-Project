﻿internal class txtSale
{
}