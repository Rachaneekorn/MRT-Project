﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        private string nall;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double start = 0, amount; //ประกาศตัวแปร
            int sale = 0;  //ประกาศตัวแปร
            {
                amount = Convert.ToDouble(txtNumber.Text);//ประกาศตัวแปร
             //บุคคลทั่วไป
            }
      if (radioPerson.Checked == true)
            {
                switch (comboBox2.Text) //เช็คเงื่อนไข
                {
                    case "หัวลำโพง": start = 16; break;
                    case "สามย่าน": start = 16; break;
                    case "สีลม": start = 19; break;
                    case "ลุมพินี": start = 21; break;
                    case "คลองเตย": start = 23; break;
                    case "ศูนย์การประชุมแห่งชาติสิริกิติ์": start = 25; break;
                    case "สุขุมวิท": start = 28; break;
                    case "เพขรบุรี": start = 30; break;
                    case "พระราม 9": start = 32; break;
                    case "ศูนย์วัฒนธรรมแห่งประเทศไทย": start = 35; break;
                    case "ห้วยขวาง": start = 37; break;
                    case "สุทธิสาร": start = 39; break;
                    case "รัชดาภิเษก": start = 42; break;
                    case "ลาดพร้าว": start = 42; break;
                    case "พหลโยธิน": start = 42; break;
                    case "สวนจตุจักร": start = 42; break;
                    case "กำแพงเพชร": start = 42; break;
                    case "บางซื่อ": start = 42; break;


                    default: MessageBox.Show(Convert.ToString("ข้อมูลไม่ครบถ้วน")); break;
                }

                //คำนวณค่าโดยสาร
                double Price = (start * amount);
                txtPrice.Text = Convert.ToString(Price);
                txtSale.Text = Convert.ToString("0");
                txtSumprice.Text = Convert.ToString(Price);
            }

            //นักเรียน/นักศึกษา
            else if (radioStudent.Checked == true)
            {
                switch (comboBox2.Text)
                {
                    case "หัวลำโพง": start = 14; sale = 2; break;
                    case "สามย่าน": start = 14; sale = 2; break;
                    case "สีลม": start = 17; sale = 3; break;
                    case "ลุมพินี": start = 19; sale = 3; break;
                    case "คลองเตย": start = 21; sale = 4; break;
                    case "ศูนย์การประชุมแห่งชาติสิริกิติ์": start = 22; sale = 4; break;
                    case "สุขุมวิท": start = 25; sale = 4; break;
                    case "เพขรบุรี": start = 27; sale = 4; break;
                    case "พระราม 9": start = 29; sale = 4; break;
                    case "ศูนย์วัฒนธรรมแห่งประเทศไทย": start = 31; sale = 5; break;
                    case "ห้วยขวาง": start = 33; sale = 5; break;
                    case "สุทธิสาร": start = 35; sale = 5; break;
                    case "รัชดาภิเษก": start = 38; sale = 5; break;
                    case "ลาดพร้าว": start = 38; sale = 5; break;
                    case "พหลโยธิน": start = 38; sale = 5; break;
                    case "สวนจตุจักร": start = 38; sale = 5; break;
                    case "กำแพงเพชร": start = 38; sale = 5; break;
                    case "บางซื่อ": start = 38; break;


                    default: MessageBox.Show(Convert.ToString("ข้อมูลไม่ครบถ้วน")); break;
                }
                //คำนวณค่าโดยสาร
                double Price = (start * amount);
                txtPrice.Text = Convert.ToString(Price);

                double Se = (sale * amount);
                txtSale.Text = Convert.ToString(Se);

                double SumPrice = (Price - Se);
                txtSumprice.Text = Convert.ToString(SumPrice);
            
            }
            //เด็กและผู้สูงอายุ
            else if (radioButton3.Checked == true)
            {
                switch (comboBox2.Text)
                {
                    case "หัวลำโพง": start = 8; break;
                    case "สามย่าน": start = 8; break;
                    case "สีลม": start = 10; break;
                    case "ลุมพินี": start = 11; break;
                    case "คลองเตย": start = 12; break;
                    case "ศูนย์การประชุมแห่งชาติสิริกิติ์": start = 13; break;
                    case "สุขุมวิท": start = 14; break;
                    case "เพขรบุรี": start = 15; break;
                    case "พระราม 9": start = 16; break;
                    case "ศูนย์วัฒนธรรมแห่งประเทศไทย": start = 18; break;
                    case "ห้วยขวาง": start = 19; break;
                    case "สุทธิสาร": start = 20; break;
                    case "รัชดาภิเษก": start = 21; break;
                    case "ลาดพร้าว": start = 21; break;
                    case "พหลโยธิน": start = 21; break;
                    case "สวนจตุจักร": start = 21; break;
                    case "กำแพงเพชร": start = 21; break;
                    case "บางซื่อ": start = 21; break;

                    default: MessageBox.Show(Convert.ToString("ข้อมูลไม่ครบถ้วน")); break;
                }
                //คำนวณค่าโดยสาร
                double Price = (start * amount);
                txtPrice.Text = Convert.ToString(Price);
                txtSale.Text = Convert.ToString("0");
                txtSumprice.Text = Convert.ToString(Price);
            }
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNumber.Clear();
            txtPrice.Clear();
            txtSale.Clear();
            txtSumprice.Clear();
            comboBox2.Text = " ";
        }
    


        private void button2_Click(object sender, EventArgs e)
        {
            txtNumber.Text = nall;
            txtPrice.Text = nall;
            txtSale.Text = nall;
            txtSumprice.Text = nall;
        }
    }
}
        